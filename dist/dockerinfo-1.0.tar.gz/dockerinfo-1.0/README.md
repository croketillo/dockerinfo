# docker-info
Extract docker container info module
